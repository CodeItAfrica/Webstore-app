import HeroPage from './pages/HeroPage';
import './App.css';

function App() {
  return (
    <div className="app">
      <HeroPage />
    </div>
  );
}

export default App;
